﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalFinanceTracker
{
    public class Report
    {
        private FinanceTracker _financeTracker;

        public Report(FinanceTracker financeTracker)
        {
            _financeTracker = financeTracker;
        }

        // Method to generate a monthly report
        public string GenerateMonthlyReport(int month, int year)
        {
            var transactions = _financeTracker.ListTransactions(month, year);
            var totalIncome = transactions.Where(t => t.Type == "Income").Sum(t => t.Amount);
            var totalExpenses = transactions.Where(t => t.Type == "Expense").Sum(t => t.Amount);
            var savings = totalIncome - totalExpenses;

            var report = new StringBuilder();
            report.AppendLine($"Monthly Report for {month}/{year}");
            report.AppendLine($"Total Income: {totalIncome:C}");
            report.AppendLine($"Total Expenses: {totalExpenses:C}");
            report.AppendLine($"Savings: {savings:C}");
            return report.ToString();
        }

        // Method to generate a yearly report
        public string GenerateYearlyReport(int year)
        {
            var transactions = _financeTracker.Budgets
                .Where(b => b.Year == year)
                .SelectMany(b => b.Transactions);

            var totalIncome = transactions.Where(t => t.Type == "Income").Sum(t => t.Amount);
            var totalExpenses = transactions.Where(t => t.Type == "Expense").Sum(t => t.Amount);
            var savings = totalIncome - totalExpenses;

            var report = new StringBuilder();
            report.AppendLine($"Yearly Report for {year}");
            report.AppendLine($"Total Income: {totalIncome:C}");
            report.AppendLine($"Total Expenses: {totalExpenses:C}");
            report.AppendLine($"Savings: {savings:C}");
            return report.ToString();
        }

        // Method to generate a report by category
        public string GenerateCategoryReport(string category)
        {
            var transactions = _financeTracker.ListTransactionsByCategory(category);
            var totalSpent = transactions.Sum(t => t.Amount);

            var report = new StringBuilder();
            report.AppendLine($"Report for Category: {category}");
            report.AppendLine($"Total Spent: {totalSpent:C}");
            return report.ToString();
        }
    }
}
