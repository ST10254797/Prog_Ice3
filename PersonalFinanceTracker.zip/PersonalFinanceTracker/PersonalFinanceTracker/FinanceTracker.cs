﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalFinanceTracker
{
    public class FinanceTracker
    {
        public List<Budget> Budgets { get; set; } = new List<Budget>();

        // Method to add a transaction
        public void AddTransaction(Transaction transaction, int month, int year)
        {
            var budget = GetOrCreateBudget(month, year);
            budget.Transactions.Add(transaction);

            if (transaction.Type == "Income")
            {
                budget.ActualIncome += transaction.Amount;
            }
            else if (transaction.Type == "Expense")
            {
                budget.ActualExpenses += transaction.Amount;
            }
        }

        // Method to get or create a budget for a specific month and year
        private Budget GetOrCreateBudget(int month, int year)
        {
            var budget = Budgets.FirstOrDefault(b => b.Month == month && b.Year == year);
            if (budget == null)
            {
                budget = new Budget(month, year);
                Budgets.Add(budget);
            }
            return budget;
        }

        // Method to set a budget for a specific month
        public void SetBudget(int month, int year, decimal incomeGoal, decimal expenseLimit)
        {
            var budget = GetOrCreateBudget(month, year);
            budget.IncomeGoal = incomeGoal;
            budget.ExpenseLimit = expenseLimit;
        }

        // Method to track progress against goals
        public (decimal incomeProgress, decimal expenseProgress) TrackBudgetProgress(int month, int year)
        {
            var budget = GetOrCreateBudget(month, year);
            var incomeProgress = budget.ActualIncome / budget.IncomeGoal * 100;
            var expenseProgress = budget.ActualExpenses / budget.ExpenseLimit * 100;
            return (incomeProgress, expenseProgress);
        }

        // Method to list all transactions for a given month
        public List<Transaction> ListTransactions(int month, int year)
        {
            var budget = Budgets.FirstOrDefault(b => b.Month == month && b.Year == year);
            return budget?.Transactions ?? new List<Transaction>();
        }

        // Method to list transactions by category
        public List<Transaction> ListTransactionsByCategory(string category)
        {
            return Budgets
                .SelectMany(b => b.Transactions)
                .Where(t => t.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        // Method to identify overspending in any category
        public List<string> IdentifyOverspending()
        {
            var overspentCategories = new List<string>();

            foreach (var budget in Budgets)
            {
                var categories = budget.Transactions
                    .Where(t => t.Type == "Expense")
                    .GroupBy(t => t.Category)
                    .Select(g => new { Category = g.Key, TotalSpent = g.Sum(t => t.Amount) });

                foreach (var category in categories)
                {
                    if (category.TotalSpent > budget.ExpenseLimit)
                    {
                        overspentCategories.Add(category.Category);
                    }
                }
            }

            return overspentCategories;
        }

        // Method to predict future spending based on past trends
        public decimal PredictFutureSpending(string category)
        {
            var pastExpenses = Budgets
                .SelectMany(b => b.Transactions)
                .Where(t => t.Type == "Expense" && t.Category == category)
                .Select(t => t.Amount);

            return pastExpenses.Average();
        }
    }

}
