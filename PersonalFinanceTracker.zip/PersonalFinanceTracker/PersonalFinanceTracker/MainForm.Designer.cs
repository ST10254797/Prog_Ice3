﻿namespace PersonalFinanceTracker
{
    partial class MainForm
    {

        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnAddTransaction;
        private System.Windows.Forms.Button btnSetBudget;
        private System.Windows.Forms.Button btnViewReport;
        private System.Windows.Forms.DataGridView dgvTransactions;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnAddTransaction = new System.Windows.Forms.Button();
            this.btnSetBudget = new System.Windows.Forms.Button();
            this.btnViewReport = new System.Windows.Forms.Button();
            this.dgvTransactions = new System.Windows.Forms.DataGridView();

            ((System.ComponentModel.ISupportInitialize)(this.dgvTransactions)).BeginInit();
            this.SuspendLayout();

            // 
            // btnAddTransaction
            // 
            this.btnAddTransaction.Location = new System.Drawing.Point(12, 12);
            this.btnAddTransaction.Name = "btnAddTransaction";
            this.btnAddTransaction.Size = new System.Drawing.Size(150, 23);
            this.btnAddTransaction.TabIndex = 0;
            this.btnAddTransaction.Text = "Add Transaction";
            this.btnAddTransaction.UseVisualStyleBackColor = true;
            this.btnAddTransaction.Click += new System.EventHandler(this.btnAddTransaction_Click);

            // 
            // btnSetBudget
            // 
            this.btnSetBudget.Location = new System.Drawing.Point(12, 41);
            this.btnSetBudget.Name = "btnSetBudget";
            this.btnSetBudget.Size = new System.Drawing.Size(150, 23);
            this.btnSetBudget.TabIndex = 1;
            this.btnSetBudget.Text = "Set Budget";
            this.btnSetBudget.UseVisualStyleBackColor = true;
            this.btnSetBudget.Click += new System.EventHandler(this.btnSetBudget_Click);

            // 
            // btnViewReport
            // 
            this.btnViewReport.Location = new System.Drawing.Point(12, 70);
            this.btnViewReport.Name = "btnViewReport";
            this.btnViewReport.Size = new System.Drawing.Size(150, 23);
            this.btnViewReport.TabIndex = 2;
            this.btnViewReport.Text = "View Report";
            this.btnViewReport.UseVisualStyleBackColor = true;
            this.btnViewReport.Click += new System.EventHandler(this.btnViewReport_Click);

            // 
            // dgvTransactions
            // 
            this.dgvTransactions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTransactions.Location = new System.Drawing.Point(12, 100);
            this.dgvTransactions.Name = "dgvTransactions";
            this.dgvTransactions.Size = new System.Drawing.Size(760, 338);
            this.dgvTransactions.TabIndex = 3;

            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvTransactions);
            this.Controls.Add(this.btnViewReport);
            this.Controls.Add(this.btnSetBudget);
            this.Controls.Add(this.btnAddTransaction);
            this.Name = "MainForm";
            this.Text = "Personal Finance Tracker";
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransactions)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion
    }
}
